browser.tabs.create({
    url: "popup.html"
  });
